# RustThreadPool

https://JimFawcett.github.io/RustThreadPool.html

Rust threadpool that accepts number of threads and function object in constructor.  Uses RustBlockingQueue

# Incomplete!
  - pending implementation of posting methods and perhaps a getting method.
  - see link above for a brief description of the design.
